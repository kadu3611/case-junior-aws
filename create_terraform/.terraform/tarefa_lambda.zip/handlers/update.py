import json

def handle_update(event, usecase, criado_por):
    task_id = event["pathParameters"]["id"]
    body = json.loads(event["body"])

    usecase.update_task(task_id, body, criado_por)
    if not task_id:
        return {
            "statusCode": 404,
            "body": json.dumps({"message": "Tarefa não encontrada"})
        }
    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Tarefa atualizada"})
    }
